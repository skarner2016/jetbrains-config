/**
 * Class    ${NAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 * @desc        
 * @author  panjunda@heyuedi.net <${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}>
 */